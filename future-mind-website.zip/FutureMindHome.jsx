
import React from "react";

export default function FutureMindHome() {
  return (
    <main className="min-h-screen bg-black text-white font-sans">
      <section className="text-center py-16 px-4">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">Future Mind</h1>
        <p className="text-lg md:text-2xl mb-6">Master AI. Shape the Future.</p>
        <div className="space-x-4">
          <button className="bg-blue-600 px-6 py-2 rounded-2xl shadow-lg hover:bg-blue-700">
            Start Learning
          </button>
          <button className="border border-white px-6 py-2 rounded-2xl hover:bg-white hover:text-black">
            Join Newsletter
          </button>
        </div>
      </section>

      <section className="py-12 px-6 max-w-4xl mx-auto">
        <h2 className="text-3xl font-semibold mb-4">Explore AI Content</h2>
        <p className="mb-6 text-gray-300">
          Future Mind offers easy-to-understand AI education: from beginner guides to advanced tutorials.
        </p>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-gray-900 p-4 rounded-2xl shadow">
            <h3 className="text-xl font-bold mb-2">What is AI?</h3>
            <p className="text-gray-400">Learn the basics of artificial intelligence and how it works.</p>
          </div>
          <div className="bg-gray-900 p-4 rounded-2xl shadow">
            <h3 className="text-xl font-bold mb-2">AI Tools</h3>
            <p className="text-gray-400">Discover the best AI tools and how to use them effectively.</p>
          </div>
          <div className="bg-gray-900 p-4 rounded-2xl shadow">
            <h3 className="text-xl font-bold mb-2">Prompt Engineering</h3>
            <p className="text-gray-400">Master the skill of talking to AI with powerful prompts.</p>
          </div>
        </div>
      </section>

      <section className="bg-gray-800 py-12 px-6 text-center">
        <h2 className="text-2xl md:text-3xl font-semibold mb-4">Want to go deeper?</h2>
        <p className="mb-6 text-gray-300">Enroll in our upcoming courses and downloadable guides.</p>
        <button className="bg-green-600 px-6 py-2 rounded-2xl shadow-lg hover:bg-green-700">
          View Courses
        </button>
      </section>

      <footer className="text-center py-6 border-t border-gray-700 mt-8 text-sm text-gray-400">
        © 2025 Future Mind. All rights reserved.
      </footer>
    </main>
  );
}
